package org.netbeans.gradle.project.view;

import javax.swing.Action;

public interface ContextActionProvider {
    public Action[] getActions();
}
