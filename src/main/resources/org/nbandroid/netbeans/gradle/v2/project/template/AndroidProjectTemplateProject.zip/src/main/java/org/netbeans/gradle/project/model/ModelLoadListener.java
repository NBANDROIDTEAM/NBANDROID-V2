package org.netbeans.gradle.project.model;

public interface ModelLoadListener {
    public void modelLoaded(NbGradleModel model);
}
