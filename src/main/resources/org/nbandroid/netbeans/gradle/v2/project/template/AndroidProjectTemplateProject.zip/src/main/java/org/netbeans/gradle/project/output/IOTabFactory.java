package org.netbeans.gradle.project.output;

public interface IOTabFactory<IOTab> {
    public IOTab create(String caption);
}
