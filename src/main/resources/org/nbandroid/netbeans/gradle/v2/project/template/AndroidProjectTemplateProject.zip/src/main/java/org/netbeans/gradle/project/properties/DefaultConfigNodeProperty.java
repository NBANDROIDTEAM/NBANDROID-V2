package org.netbeans.gradle.project.properties;

public final class DefaultConfigNodeProperty extends AbstractConfigNodeProperty {
    public static final DefaultConfigNodeProperty INSTANCE = new DefaultConfigNodeProperty();
}
