package org.netbeans.gradle.project;

public interface ProjectIssueRef {
    public void setInfo(ProjectIssue info);
}
