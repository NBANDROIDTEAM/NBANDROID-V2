package org.netbeans.gradle.project.properties;

public enum PlatformSelectionMode {
    BY_VERSION,
    BY_LOCATION
}
