package org.netbeans.gradle.project.java.properties;

public enum DebugMode {
    DEBUGGER_LISTENS,
    DEBUGGER_ATTACHES
}
