package org.netbeans.gradle.project.api.entry;

import java.io.IOException;
import javax.annotation.Nonnull;
import org.netbeans.api.project.Project;

/**
 * @deprecated Use {@link GradleProjectExtensionDef} instead.<P>
 *
 * Defines a query for extending Gradle based projects. This query must be used
 * by other plugins to integrate with the Gradle project type. That is,
 * instances of {@code GradleProjectExtensionQuery} are notified upon each
 * project load.
 * <P>
 * Instances of {@code GradleProjectExtensionQuery} are expected to be installed
 * into the global default lookup: {@code org.openide.util.Lookup.getDefault()}
 * via the {@code org.openide.util.lookup.ServiceProvider} annotation.
 * <P>
 * <B>Note</B>: As of the current implementation, this query must be on the
 * global lookup prior loading the project. This means that plugins integrating
 * with Gradle projects require NetBeans to be restarted after being installed.
 * <P>
 * Instances of this interface must be safe to be called by multiple threads
 * concurrently but they are not required to be
 * <I>synchronization transparent</I> unless otherwise noted.
 */
@Deprecated
public interface GradleProjectExtensionQuery {
    /**
     * @deprecated This interface is deprecated.<P>
     *
     * Attaches the extension to a particular project which has just been
     * loaded. This method is called for each loaded project and is called
     * exactly once.
     * <P>
     * You can expect the following queries to be on the project's lookup even
     * when this method is being called:
     * <ul>
     *  <li>{@link org.netbeans.spi.project.ProjectState}</li>
     *  <li>{@link org.netbeans.api.project.ProjectInformation}</li>
     *  <li>{@link org.netbeans.spi.project.AuxiliaryConfiguration}</li>
     *  <li>{@link org.netbeans.spi.project.AuxiliaryProperties}</li>
     *  <li>{@link org.netbeans.gradle.project.api.task.GradleCommandExecutor}</li>
     *  <li>{@link org.netbeans.gradle.project.api.property.GradleProperty.SourceEncoding}</li>
     *  <li>{@link org.netbeans.gradle.project.api.property.GradleProperty.ScriptPlatform}</li>
     *  <li>{@link org.netbeans.gradle.project.api.property.GradleProperty.SourceLevel}</li>
     *  <li>{@link org.netbeans.gradle.project.api.property.GradleProperty.BuildPlatform}</li>
     * </ul>
     *
     * @param project the project which has been loaded and to which this
     *   extension is to be attached. This argument cannot be {@code null}.
     * @return the {@code GradleProjectExtension} handling the extension of the
     *   loaded project. This method may never return {@code null}.
     *
     * @throws IOException thrown if some serious I/O error prevented the
     *   extension from being loaded. Throwing this exception will prevent the
     *   extension from being applied to this project (even after it changes),
     *   so this exception should only be thrown in the extreme cases.
     */
    @Nonnull
    @Deprecated
    public GradleProjectExtension loadExtensionForProject(@Nonnull Project project) throws IOException;
}
