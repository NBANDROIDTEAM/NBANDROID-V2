package org.netbeans.gradle.project.model;

public interface PersistentModelStore<T> extends ModelPersister<T>, PersistentModelRetriever<T> {
}
