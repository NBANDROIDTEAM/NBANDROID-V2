package org.netbeans.gradle.project;

public interface ProjectInitListener {
    public void onInitProject();
}
