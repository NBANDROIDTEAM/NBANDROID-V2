package org.netbeans.gradle.project.util;

public interface RefreshableChildren {
    public void refreshChildren();
}
