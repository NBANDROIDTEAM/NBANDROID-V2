/**
 * Contains interfaces related to event handling. Everything in this package is
 * just a copy from the {@code JTrim} library and will effectively be replaced
 * by <B>JTrim</B> interfaces in the future (in NetBeans 7.4).
 */
package org.netbeans.gradle.project.api.event;
