package org.netbeans.gradle.project.output;

public interface OutputLinkFinder {
    public OutputLinkDef tryFindLink(String line);
}
