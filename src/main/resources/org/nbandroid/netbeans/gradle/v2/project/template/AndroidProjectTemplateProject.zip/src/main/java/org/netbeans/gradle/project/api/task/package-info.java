/**
 * Contains classes and interfaces related to handling Gradle commands.
 */
package org.netbeans.gradle.project.api.task;
