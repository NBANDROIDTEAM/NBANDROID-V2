package org.netbeans.gradle.project.java;

public interface JavaModelChangeListener {
    public void onModelChange();
}
