package org.netbeans.gradle.project.license;

public interface LicenseDef {
    public String getLicenseId();
}
