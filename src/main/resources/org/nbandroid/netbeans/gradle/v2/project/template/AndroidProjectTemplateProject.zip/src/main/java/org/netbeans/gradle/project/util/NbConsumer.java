package org.netbeans.gradle.project.util;

public interface NbConsumer<T> {
    public void accept(T t);
}
