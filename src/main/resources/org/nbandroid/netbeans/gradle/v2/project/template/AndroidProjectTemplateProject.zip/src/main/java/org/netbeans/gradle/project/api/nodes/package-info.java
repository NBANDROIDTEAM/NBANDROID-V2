/**
 * Contains classes and interfaces related to adding nodes the project view
 * for Gradle projects.
 */
package org.netbeans.gradle.project.api.nodes;
