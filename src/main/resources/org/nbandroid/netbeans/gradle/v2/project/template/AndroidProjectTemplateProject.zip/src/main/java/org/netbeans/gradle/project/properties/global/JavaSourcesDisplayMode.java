package org.netbeans.gradle.project.properties.global;

public enum JavaSourcesDisplayMode {
    DEFAULT_MODE,
    GROUP_BY_SOURCESET;
}
